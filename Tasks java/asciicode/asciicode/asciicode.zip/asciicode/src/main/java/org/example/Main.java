package org.example;

import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    { System.out.println("Enter the Character to get the ASCII value of it : " );
        Scanner in = new Scanner(System.in);
        char ch1 = in.next().charAt(0);
              int asciivalue = ch1;
        System.out.println("The ASCII value of " + ch1 + " is: " + asciivalue);
    }
}